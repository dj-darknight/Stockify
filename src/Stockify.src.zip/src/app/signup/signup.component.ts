import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup} from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { HttpResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  constructor(private router: Router, private _https:HttpClientModule,private _toastr:ToastrService) { }
  signup: FormGroup|any;
  signuser:any;
  ngOnInit(): void {
    this.signup = new FormGroup({
      'fname': new FormControl(),
      'lname': new FormControl(),
      'email': new FormControl(),
      'phone': new FormControl(),
      'password': new FormControl()
   })
  
  }
 
  sbtn(){
    this.router.navigate(['login']);
    //$('.form-box1').css('z-index','99');
    $('.form-box').css('display','block');
    $('.form-box1').css('display','none');
  }
}
